SIMPLE HOTEL MANAGEMENT SYSTEM IN C++


DEVELOPED BY NEMONET THE YOUNG PROGRAMMER (TYP)

***** IF YOU FIND ANY ERRORS OR ANY PROBLEMS RELATED THIS PROGRAM, FEEL FREE TO CONTACT US *****  


***** LEAVE A COMMENT IF YOU LOVED OUR WORK *****


*****  https://the-young-programmer.github.io/The-Young-Programmer/ *****





*****     download CodeBlocks    *****

    	I will be using Code::Blocks in this Project, 
	which I believe is a good place to start.
  	  You can find the latest version of Codeblocks at http://www.codeblocks.org/.

    	Download the mingw-setup.exe file, which will install the text editor with a compiler.

download Project

    Download the Hotel Management ZIP file
    run the main.exe file by double clicking it



#THANK YOU FOR DOWNLOADING